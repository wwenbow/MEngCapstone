
#ifndef HelloUSBWorld_H
#define HelloUSBWorld_H

extern void UserInit(void);
extern void ProcessIO(int n);

#endif

